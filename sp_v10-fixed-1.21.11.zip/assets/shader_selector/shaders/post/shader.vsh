#version 330

uniform sampler2D MainSampler;
uniform sampler2D DataSampler;
uniform sampler2D BlurSampler;

#moj_import <shader_selector:marker_settings.glsl>
#moj_import <shader_selector:utils.glsl>
#moj_import <shader_selector:data_reader.glsl>
#moj_import <minecraft:globals.glsl>

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

in vec4 Position;

out vec2 texCoord;

void main(){
    // REQUIRED Blit Copy Statement
    float x = -1.; 
    float y = -1.;
    if (Position.x > .001){
        x = 1.;
    }
    if (Position.y > .001){
        y = 1.;
    }
    gl_Position = vec4(x, y, .2, 1.);
    //////////////////////////////////////

    // Normalized pixel coordinates (from 0 to 1)
    texCoord = Position.xy;

    float t = GameTime;
    float freq = (1.-readChannel(SCREENSHAKE_FREQUENCY)) * 65025.; // Channel #2 Controls Shake Freq
    float magnitude = (1.-readChannel(SCREENSHAKE_MAGNITUDE)) * .03; // Channel #1 Controls Shake Magnitude

    // Zoom in to prevent bars
    texCoord *= 1. - magnitude * 2.;
    texCoord.y += magnitude;

    texCoord.x += cos(sin(t * freq) * 3.) * magnitude;
    texCoord.y += sin(cos(t * freq) * 3.) * magnitude;
}

