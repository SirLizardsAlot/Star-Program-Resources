PREFIX = '{"texture_size":[4,4],"textures":{"0":"block/white_stained_glass","particle":"block/white_stained_glass"},"elements":['
SUFFIX = ']}'
RES = 128

import math

def func(x,y,z,t):
    #sphere
    #dist = math.sqrt((.5 - x)**2 + (.5 - y)**2 + (.5 - z)**2)
    #return (dist < .5 and dist > .495)

    global RES
    dz = (math.sin(z*5+time/10)+1)/5
    dx = (math.cos(x*5+time/10)+1)/5
    
    return (round((y)*RES) == round((dx+dz)*RES))

scale = 16 / RES

for time in range(62):
    with open(f"C:/Users/jona23/AppData/Roaming/PrismLauncher/instances/terf/.minecraft/resourcepacks/TERFresources/assets/terf/models/item/visual/test{time}.json", "w", encoding="utf-8") as file:
        elements = []
        print("Generating file...")

        for x in range(RES):
            print(f"Generating layer {x+1}/{RES} in frame {time}")
            for y in range(RES):
                for z in range(RES):
                    if func(x/RES,y/RES,z/RES,time):
                        dx = x*scale
                        dy = y*scale
                        dz = z*scale
                        elements.append('{"from":['+ f'{dx},{dy},{dz}' +'],"to":['+ f'{dx+scale},{dy+scale},{dz+scale}' +'],"faces":{"north":{"uv":[0,0,16,16],"texture":"#0"},"east":{"uv":[0,0,16,16],"texture":"#0"},"south":{"uv":[0,0,16,16],"texture":"#0"},"west":{"uv":[0,0,16,16],"texture":"#0"},"up":{"uv":[0,0,16,16],"texture":"#0"},"down":{"uv":[0,0,16,16],"texture":"#0"}}},')

        file.write(PREFIX + ''.join(elements)[:-1] + SUFFIX)
        print("Complete!")

    with open(f"C:/Users/jona23/AppData/Roaming/PrismLauncher/instances/terf/.minecraft/resourcepacks/TERFresources/assets/terf/items/visual/test{time}.json", "w", encoding="utf-8") as file:
        file.write('{"model":{"type":"minecraft:model","model":"terf:item/visual/test'+str(time)+'"}}')

