PREFIX = '{"texture_size":[4,4],"textures":{"0":"terf:item/model/dem_dust","particle":"terf:item/model/dem_dust"},"elements":['
SUFFIX = ']}'
SCALE = 12

import random

elements = ''
for i in range(100):
    x = random.uniform(-16,32-SCALE)
    y = random.uniform(-16,32-SCALE)
    z = random.uniform(-16,32-SCALE)
    
    elements = elements + '{"from":['+ f'{x},{y},{z}' +'],"to":['+ f'{x+SCALE},{y+SCALE},{z}' +'],"rotation":{"angle":' + str(random.randint(-2,2)*22.5) + ',"axis":"' + random.choice(['x', 'y', 'z']) + '","origin":['+ f'{x},{y},{z}' +']},"faces":{"north":{"uv":[0,0,16,16],"texture":"#0"},"east":{"uv":[0,0,0,8],"texture":"#0"},"south":{"uv":[0,0,16,16],"texture":"#0"},"west":{"uv":[0,0,0,8],"texture":"#0"},"up":{"uv":[8,0,0,0],"texture":"#0"},"down":{"uv":[8,0,0,0],"texture":"#0"}}},'

with open("C:/Users/jona23/AppData/Roaming/PrismLauncher/instances/terf/.minecraft/resourcepacks/DEM resources/assets/terf/models/item/visual/dem/dust.json", "w", encoding="utf-8") as file:
    file.write(PREFIX + elements[:-1] + SUFFIX)