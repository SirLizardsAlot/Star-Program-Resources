python voicelines.py --post
timeout /t 5