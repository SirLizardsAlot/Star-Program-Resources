# Me trying to figure out the algorithm at 3am:

# If the file is a BASE, generate a model with the BASE
# If the file is an OVERLAY, generate a model with the BASE and OVERLAY, if a SECONDARY exists, generate a model with the BASE and OVERLAY and SECONDARY
# If the file is a SECONDARY, generate a model with the BASE, OVERLAY(if it exists) and SECONDARY

# If the file is a 1, generate a model with the 1
# If the file is 2 an 2, generate a model with the 1 and 2, if a 3 exists, generate a model with the 1 and 2 and 3 and 4(if it exists)
# If the file is 3 a 3, generate a model with the 1, 2(if it exists) and 3, if a 4 exists, generate a model with the 1, 2(if it exists) and 3 and 4
# If the file is 4 a 4, generate a model with the 1, 2(if it exists) and 3(if it exists) and 4

# The model generated ALWAYS contains 1
# The model generated ALWAYS contains the current layer, aka layer 10 would always layer 10
# If the layer is a 10 for example, it makes a model with 1,(2,3,4,5,6,7,8,9 if they exist) and 10
# If the layer is a 5 for example, it makes a model with (1,2,3,4,5) and (1,2,3,4,5,6) if a layer 6 exists and (1,2,3,4,5,6,7) if a layer 7 exists and (1,2,3,4,5,6,7,8) if a layer 8 exists and (1,2,3,4,5,6,7,8,9) if a layer 9 exists and (1,2,3,4,5,6,7,8,9,10) if a layer 10 exists

# If any of the layers cannot be found in the same folder, refer to the one in dull, if its not found in dull either it dosent exist

import os

root_folder = os.path.dirname(os.path.abspath(__file__))

materials_folder = os.path.join(root_folder, "textures/item/material")
items_folder = os.path.join(root_folder, "items/material")
models_folder = os.path.join(root_folder, "models/item/material")

layerSuffixes = [".png","_overlay.png","_secondary.png"]

# If the layer dosent exist in the same folder, return the same path but inside the dull folder
def getLayerPath(material, materialType, layer):
    texturePath = material + "/" + materialType+layerSuffixes[layer]
    path = os.path.join(materials_folder, texturePath)
    if os.path.isfile(path):
        return texturePath
    
    # Mayyybe only refer to the dull folder if its the base
    if layer != 0:
        return None

    texturePath = "dull/" + materialType+layerSuffixes[layer]
    path = os.path.join(materials_folder, texturePath)
    if os.path.isfile(path):
        return texturePath
    
    return None

# Turn _overlay, _secondary and stuff into numbers for computing
def layerFromName(name):
    layerName = name.split("_")[-1]
    layer = None
    try:
        layer = layerSuffixes.index("_"+layerName)
    except ValueError:
        layer = 0
    materialType = file_name[:-len(layerSuffixes[layer])]
    return materialType, layer

# Generate a model with layers up to (layer)
def generateModel(material, materialType, layer):
    textureLayers = ''
    tintLayers = ''
    validLayerCount = 0
    for i in range(layer+1):
        texturePath = getLayerPath(material, materialType, i)
        # If the layer dosent exist, continue
        if not texturePath:
            continue
        
        textureLayers = textureLayers + f'"layer{validLayerCount}":"terf:item/material/{texturePath[:-4]}",'
        tintLayers = tintLayers + '{"type":"minecraft:custom_model_data","index":'+str(validLayerCount)+',"default":16777215},'
        validLayerCount += 1

    # Make the model file
    current_path = os.path.join(models_folder, material, materialType+layerSuffixes[layer][:-4]+".json")
    os.makedirs(os.path.dirname(current_path), exist_ok=True)
    with open(current_path, "w") as file:
        model = '{"parent":"minecraft:item/generated","textures":{'+textureLayers[:-1]+'}}'
        print(model)
        file.write(model)

    # Make the item referencer
    current_path = os.path.join(items_folder, material, materialType+layerSuffixes[layer][:-4]+".json")
    os.makedirs(os.path.dirname(current_path), exist_ok=True)
    with open(current_path, "w") as file:
        model = '{"model":{"type":"minecraft:model","model":"terf:item/material/'+f"{material}/{materialType+layerSuffixes[layer][:-4]}"+'","tints":['+tintLayers[:-1]+']}}'
        print(model)
        file.write(model)

# The Code
for folder_path, _, files in os.walk(materials_folder):
    for file_name in files:
        if not file_name.endswith(".png"):
            continue

        material = os.path.basename(folder_path)

        materialType, layer = layerFromName(file_name)

        if layer == 0:
            generateModel(material, materialType, layer)
            continue



        # Check if layers current and further up exist
        for i in range(layer, len(layerSuffixes)):
            # If the layer exists, make it generate a model
            if not getLayerPath(material, materialType, i):
                continue
            generateModel(material, materialType, i)

            