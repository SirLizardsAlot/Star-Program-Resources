# I made this in 30s with chatgpt because i was lazy to put all the disc layers into a photo editor one by one 

# Set the path to your folder of images
input_folder = "C:/Users/jona23/AppData/Roaming/PrismLauncher/instances/terf/.minecraft/resourcepacks/DEM resources/assets/minecraft/textures/font/dem/disc/s"
output_folder = "C:/Users/jona23/AppData/Roaming/PrismLauncher/instances/terf/.minecraft/resourcepacks/DEM resources/assets/minecraft/textures/font/dem/disc"

import os
from PIL import Image, ImageEnhance

# Enhancement factors
brightness_factor = 1  # >1 = brighter
contrast_factor = 1    # >1 = more contrast
sharpness_factor = 1.5   # >1 = sharper

# Create the output folder if it doesn't exist
os.makedirs(output_folder, exist_ok=True)

# Loop through all image files
for filename in os.listdir(input_folder):
    if filename.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".gif")):
        image_path = os.path.join(input_folder, filename)
        img = Image.open(image_path)

        # Convert image to grayscale with or without alpha
        if img.mode in ("RGBA", "LA"):
            bw_img = img.convert("LA")
        else:
            bw_img = img.convert("L")

        # Apply enhancements
        bw_img = ImageEnhance.Brightness(bw_img).enhance(brightness_factor)
        bw_img = ImageEnhance.Contrast(bw_img).enhance(contrast_factor)
        bw_img = ImageEnhance.Sharpness(bw_img).enhance(sharpness_factor)

        # Save result
        save_path = os.path.join(output_folder, filename)
        bw_img.save(save_path)
        print(f"Processed: {filename}")

print("All images converted to enhanced black & white.")
