#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D MainSampler;
uniform sampler2D MainDepthSampler;
uniform sampler2D DataSampler;

#include <shader_selector:marker_settings.glsl>
#include <shader_selector:utils.glsl>
#include <shader_selector:data_reader.glsl>
#include <minecraft:globals.glsl>
uniform sampler2D SkyDataSampler;
#define DFSKY_SAMPLER SkyDataSampler
#include <dfsky:sky.glsl>

layout(location = 0) in vec2 baseTexCoord;
layout(location = 2) flat in mat3 spCameraToWorld;
layout(location = 6) flat in float spCrop;
layout(location = 7) flat in float spTime;
layout(location = 8) flat in int spHasCamera;
layout(location = 9) flat in vec4 spSkyA;
layout(location = 10) flat in vec4 spSkyB;
layout(location = 11) flat in vec4 spSkyC;
layout(location = 12) flat in vec4 spSkyD;
vec2 texCoord;

layout(location = 0) out vec4 fragColor;


DfSkyState spNoonState() {
    return DfSkyState(
    6000.0000000000,
    0.0000000000,
    0.0000000000,
    vec3(0.4705882353, 0.6549019608, 1.0000000000),
    vec3(0.7347052273, 0.8346482470, 1.0000000000),
    vec4(1.0000000000, 1.0000000000, 1.0000000000, 0.8000000000),
    vec4(1.0000000000, 0.8980392157, 0.2000000000, 0.0000000000)
);
}

vec4 spScene(vec2 uv) {
    vec4 source = texture(MainSampler, uv);
    float visibility = clamp(1.0 - source.a, 0.0, 1.0);
    // A cleared background has no world depth. Ordinary opaque geometry has
    // alpha one. Ignore byte-sized incidental coverage errors on cutout edges.
    if (spHasCamera != 0 && visibility > 0.02 && texture(MainDepthSampler, uv).r > 0.0) {
        vec3 ray = normalize(spCameraToWorld * vec3(uv * 2.0 - 1.0, 1.0));
        dfskyState = spNoonState();
        vec3 baseline = dfsky_render(ray, 0.0);
        dfskyState = DfSkyState(spTime, spSkyA.x, spSkyA.y,
            vec3(spSkyA.zw, spSkyB.x), spSkyB.yzw, spSkyC, spSkyD);
        float cloudClock = mod(GameTime * 1200.0 * 0.6, 3072.0);
        vec3 replacement = dfsky_render(ray, cloudClock);
        source.rgb = clamp(source.rgb + visibility * (replacement - baseline), 0.0, 1.0);
    }
    return vec4(source.rgb, 1.0);
}

float random(float x) {
    return fract(sin(x * 12.9898) * 43758.5453);
}

vec3 tintScreen(float time) {
    // Normalize time to [0, 1] for the full color cycle
    float hue = mod(time, 1.0);
    
    // Calculate RGB based on the hue value
    vec3 color;
    if (hue < 1.0 / 6.0) {
        color = vec3(0.0, hue * 6.0, 1.0); // Cyan to Green
    } else if (hue < 2.0 / 6.0) {
        color = vec3(0.0, 1.0, 1.0 - (hue - 1.0 / 6.0) * 6.0); // Green to Yellow
    } else if (hue < 3.0 / 6.0) {
        color = vec3((hue - 2.0 / 6.0) * 6.0, 1.0, 0.0); // Yellow to Red
    } else if (hue < 4.0 / 6.0) {
        color = vec3(1.0, 1.0 - (hue - 3.0 / 6.0) * 6.0, 0.0); // Red to Magenta
    } else if (hue < 5.0 / 6.0) {
        color = vec3(1.0, 0.0, (hue - 4.0 / 6.0) * 6.0); // Magenta to Blue
    } else {
        color = vec3(1.0 - (hue - 5.0 / 6.0) * 6.0, 0.0, 1.0); // Blue to Cyan
    }
    
    return color;
}

vec4 demDistortion(float time, float controlStrength) {
    // Fetch the current pixel color from the texture
    vec4 color = spScene(texCoord);

    float t = time;
    float intensity = max(0.,pow(controlStrength+1,3)-1 - random(t)/100.);

    // Get the red component of the color
    float redValue = color.r;

    // Calculate the center of the screen in texture coordinates
    vec2 center = vec2(0.5, 0.5);
    
    // Compute the direction vector from the current pixel to the center
    vec2 direction = center - texCoord;
    
    // Compute the amount to pull the pixel based on the red component
    float pullAmount = redValue * intensity; // Adjust this multiplier to control the strength of the pull
    
    // Calculate the new texture coordinate by pulling towards the center
    vec2 pulledTexCoord = texCoord + direction * pullAmount;
    
    // Fetch the color from the texture at the new coordinate
    vec4 pulledColor = spScene(pulledTexCoord);

    // Output the pulled color
    return pulledColor;
}

// STAR_ESRI_IMPACT_BEGIN
float spEsriImpactControl() {
    if (!controlStateValid()) return 0.0;
    ivec4 packet = ivec4(round(texelFetch(DataSampler, ivec2(0, RESERVED_CONTROL), 0) * 255.0));
    if (packet.r != MARKER_RED || packet.g != 1 || packet.a != 255 || packet.b < 1 || packet.b > 3) return 0.0;
    float seen = decodeColor(texelFetch(DataSampler, ivec2(1, RESERVED_CONTROL), 0));
    float clock = GameTime * CONTROL_PERIOD;
    if (!controlFiniteTime(seen) || !controlFiniteTime(clock) || controlElapsed(clock, seen) > 0.05) return 0.0;
    // Hit-frame identities are discrete. They bypass the generic held-control
    // interpolation and expire after one native tick without fresh packets.
    return float(packet.b) / 255.0;
}

vec3 spEsriSample(vec2 uv, vec2 pixel) {
    return texture(MainSampler, clamp(uv, pixel * 0.5, 1.0 - pixel * 0.5)).rgb;
}

float spEsriLuma(vec3 color) {
    return dot(color, vec3(0.2126, 0.7152, 0.0722));
}

vec4 spEsriImpact(vec4 source, vec2 uv, float wire) {
    int phase = int(floor(wire * 255.0 + 0.5));
    if (phase < 1 || phase > 3) return source;

    // View-relative pressure. The machine's separate display flare owns the
    // world-space epicenter and ordinary depth testing at the aperture.
    vec2 size = vec2(textureSize(MainSampler, 0));
    vec2 pixel = 1.0 / size;
    vec2 aspect = size / min(size.x, size.y);
    vec2 view = (uv - 0.5) * aspect;
    float radius = length(view);
    vec2 direction = view / max(radius, 0.001);
    float angle = radius > 0.0 ? atan(direction.y, direction.x) : 0.0;
    float sector = (angle + 3.141593) * (56.0 / 6.283186);
    float variation = random(floor(sector) + 0.7);

    if (phase == 1) {
        // Two-tone contact drawing with a pale tear and tapering radial ink.
        vec2 dx = vec2(1.5 * pixel.x, 0.0);
        vec2 dy = vec2(0.0, 1.5 * pixel.y);
        float edge = abs(spEsriLuma(spEsriSample(uv + dx, pixel)) - spEsriLuma(spEsriSample(uv - dx, pixel)))
                   + abs(spEsriLuma(spEsriSample(uv + dy, pixel)) - spEsriLuma(spEsriSample(uv - dy, pixel)));
        float contour = smoothstep(0.065, 0.23, edge);
        float lit = smoothstep(0.32, 0.48, spEsriLuma(source.rgb));
        float rim = 1.0 - smoothstep(0.08, 0.58, radius);
        float streak = 1.0 - smoothstep(0.025, 0.10 + 0.12 * variation, abs(fract(sector) - 0.5));
        streak *= smoothstep(0.09 + 0.24 * variation, 0.32 + 0.24 * variation, radius);
        streak *= 1.0 - smoothstep(0.36 + 0.36 * variation, 0.54 + 0.36 * variation, radius);
        float tear = 1.0 - smoothstep(0.015, 0.095, radius + sin(angle * 7.0) * radius * 0.25);
        float ink = max(0.02 + lit * (0.10 + 0.40 * rim), max(contour * (0.45 + 0.30 * rim), streak * 0.68));
        return vec4(vec3(max(ink, tear * 0.86)), source.a);
    }

    // A narrow, broken pressure front kicks scene detail outward. Adding the
    // sample delta to the composed frame retains the underlying facility tint.
    bool recoil = phase == 2;
    float front = (recoil ? 0.30 : 0.61) + 0.012 * sin(angle * 7.0) + 0.008 * sin(angle * 19.0);
    float offset = radius - front;
    float band = 1.0 - smoothstep(0.010, recoil ? 0.095 : 0.055, abs(offset));
    if (band <= 0.0) return source;
    float crest = (1.0 - smoothstep(0.002, recoil ? 0.014 : 0.010, abs(offset)))
        * (0.48 + 0.52 * variation);
    vec2 pull = direction / aspect * band * (recoil ? 0.046 : 0.012);
    vec3 original = spEsriSample(uv, pixel);
    vec3 compressed = spEsriSample(uv - pull, pixel);
    vec3 fringe = spEsriSample(uv + pull * 0.35, pixel);
    vec3 rgb = source.rgb + (vec3(fringe.r, compressed.g, compressed.b) - original) * (recoil ? 0.80 : 0.36);
    rgb += vec3(0.08, 0.52, 0.68) * crest * (recoil ? 0.52 : 0.17);
    return vec4(clamp(rgb, 0.0, 1.0), source.a);
}
// STAR_ESRI_IMPACT_END

void main() {
    texCoord = vec2(0.5) + (baseTexCoord - vec2(0.5)) * spCrop;
    float alarm_effects = readChannel(ALARM_EFFECTS);

    if (alarm_effects > 0.) {
        if (alarm_effects == 1./255.) {
            float temp = (sin(GameTime*5000.)+4.)/30.;
            fragColor = spScene(texCoord) - vec4(0.,temp,temp,0.);
        } else if (alarm_effects == 2./255.) {
            float temp = sin(GameTime*21000.)+1.;
            
            vec3 tint = tintScreen(mod(GameTime*2500. ,1.0));
            fragColor = vec4(spScene(texCoord).rgb / (min(tint+temp/5.,.7)+.3) ,1.);

        } else if (alarm_effects == 4./255.) {        
            vec3 tint = tintScreen(mod(GameTime*25000. ,1.0));
            fragColor = vec4(spScene(texCoord).rgb / (min(tint+.2,.7)+.3) ,1.);

        } else if (alarm_effects == 5./255.) {
            float temp = sin(GameTime*21000.)+1.;
            
            vec3 tint = tintScreen(mod(GameTime*10000. ,1.0));
            fragColor = vec4(spScene(texCoord).rgb / (min(tint+temp/5.,.5)+.5) ,1.);

        } else if (alarm_effects == 8./255.) {
            float temp = sin(GameTime*100000.)+1.;
            
            vec3 tint = tintScreen(mod(GameTime*2500. ,1.0));
            fragColor = vec4(spScene(texCoord).rgb / (min(tint+temp/5.,.5)+.5) ,1.);

        } else if (alarm_effects == 10./255.) {
            float temp = sin(GameTime*21000.)+1.;
            
            vec3 tint = tintScreen(mod(GameTime*1000. ,1.0));
            fragColor = vec4(spScene(texCoord).rgb / (min(tint+temp/5.,.5)+.5) ,1.);
        } else if (alarm_effects > 10./255.) {      
                  
            fragColor = demDistortion(GameTime, (alarm_effects-10./255.)/2.);
        } else {
            fragColor = spScene(texCoord);
        }
    } else {
        fragColor = spScene(texCoord);
    }
    fragColor = spEsriImpact(fragColor, texCoord, spEsriImpactControl());
}