#ifndef STAR_WORMHOLE_TUNNEL_GLSL
#define STAR_WORMHOLE_TUNNEL_GLSL

vec2 wormholeCenter(float z, float time) {
    float turn = time * 0.11;
    return 0.19 * vec2(sin(z * 0.39 + turn) - sin(turn),
                       cos(z * 0.31 - turn) - cos(turn)) * (1.0 - exp(-z));
}

float wormholeRadius(float z, float time) {
    return 1.07 + 0.07 * sin(z * 1.8 - time * 0.7)
                + 0.025 * sin(z * 4.7 + time * 0.35);
}

vec4 renderWormhole(vec2 uv, vec3 viewPosition, float time) {
    vec2 aperture = (uv - 0.5) * vec2(2.0, -2.0);
    float radius = length(aperture);
    float alpha = 1.0 - smoothstep(0.977, 1.0, radius);
#ifdef OIT_ALPHA_ONLY
    if (radius >= 1.0) {
        discard;
    }
    // OIT's depth/alpha pass needs the same silhouette, without shading walls.
    return vec4(0.0, 0.0, 0.0, alpha);
#else

    // Recover the actual transformed glyph plane from perspective-correct
    // varyings. The eye ray is expressed in that plane's own coordinate frame,
    // so turning the entity and walking around it both alter the tunnel view.
    vec3 dpdx = dFdx(viewPosition);
    vec3 dpdy = dFdy(viewPosition);
    vec2 duvdx = dFdx(uv);
    vec2 duvdy = dFdy(uv);
    float determinant = duvdx.x * duvdy.y - duvdx.y * duvdy.x;
    float safeDeterminant = abs(determinant) > 1e-12 ? determinant
        : (determinant < 0.0 ? -1e-12 : 1e-12);
    vec3 tangent = (dpdx * duvdy.y - dpdy * duvdx.y) / safeDeterminant;
    vec3 bitangent = (dpdy * duvdx.x - dpdx * duvdy.x) / safeDeterminant;
    float tangentLength = max(length(tangent), 1e-7);
    float bitangentLength = max(length(bitangent), 1e-7);
    tangent /= tangentLength;
    bitangent /= bitangentLength;
    vec3 normal = normalize(cross(tangent, bitangent));
    vec3 eyeRay = normalize(viewPosition);
    float axialScale = 0.5 * (tangentLength + bitangentLength);
    vec3 ray = normalize(vec3(dot(eyeRay, tangent) * axialScale / tangentLength,
                             -dot(eyeRay, bitangent) * axialScale / bitangentLength,
                             max(abs(dot(eyeRay, normal)), 0.025)));

    // Calculate screen derivatives before discarding the circular exterior.
    if (radius >= 1.0) {
        discard;
    }

    vec3 point = vec3(aperture, 0.015);
    float travel = 0.0;
    float wallDistance = 1.0;
    bool wallHit = false;
    // Fixed work bound and early exits keep the effect limited to its aperture.
    for (int stepIndex = 0; stepIndex < 64; ++stepIndex) {
        point = vec3(aperture, 0.015) + ray * travel;
        vec2 wallPoint = point.xy - wormholeCenter(point.z, time);
        wallDistance = wormholeRadius(point.z, time) - length(wallPoint);
        if (wallDistance < 0.006) {
            wallHit = true;
            break;
        }
        if (point.z > 36.0) {
            break;
        }
        travel += max(wallDistance * 0.62, 0.008);
    }

    vec3 color = vec3(0.002, 0.003, 0.012);
    if (wallHit) {
        vec2 wallPoint = point.xy - wormholeCenter(point.z, time);
        float angle = atan(wallPoint.y, wallPoint.x);
        float depth = point.z;
        float twist = angle * 7.0 + depth * 0.95 - time * 0.45;
        float ribs = pow(max(0.0, cos(twist + 0.5 * sin(depth * 1.2))), 12.0);
        float rings = pow(max(0.0, cos(depth * 5.0 - time * 1.35
            + 0.5 * sin(angle * 3.0 + depth * 0.4))), 20.0);
        float filaments = pow(max(0.0, cos(angle * 19.0 - depth * 2.1
            + time * 0.6)), 28.0);
        float cloud = 0.5 + 0.5 * sin(angle * 4.0 + sin(depth * 0.8 - time * 0.15));
        vec3 wallColor = mix(vec3(0.13, 0.025, 0.32), vec3(0.015, 0.29, 0.40), cloud);
        color = wallColor * (0.20 + 0.46 * ribs);
        color += vec3(0.075, 0.56, 0.70) * rings * (0.45 + 0.55 * ribs);
        color += vec3(0.36, 0.13, 0.63) * filaments * 0.45;
        color *= exp(-depth * 0.105);
        color += vec3(0.006, 0.009, 0.022) * (1.0 - exp(-depth * 0.09));
    } else {
        // The unresolved axis fades to a deep, distant throat rather than a cap.
        float throat = exp(-length(point.xy - wormholeCenter(point.z, time)) * 3.0);
        color += vec3(0.012, 0.018, 0.055) * throat;
    }

    float rim = exp(-pow((radius - 0.938) / 0.022, 2.0));
    float outerGlow = exp(-pow((radius - 0.945) / 0.065, 2.0));
    float angle = atan(aperture.y, aperture.x);
    float rimCurrent = 0.78 + 0.22 * sin(angle * 11.0 - time * 1.5);
    color += vec3(0.10, 0.72, 0.90) * rim * rimCurrent;
    color += vec3(0.10, 0.06, 0.30) * outerGlow;
    color = color / (vec3(1.0) + color * 0.35);
    return vec4(color, alpha);
#endif
}

vec4 renderWormholeSeal(vec2 uv, vec3 viewPosition, float time, float carrier) {
    // Closure uses the upper half of TextDisplay's signed opacity byte.
    // Render visibility is authored here and reaches zero before the entity expires.
    float progress = clamp((1.0 - carrier) / 0.46, 0.0, 1.0);
    float intake = smoothstep(0.0, 0.55, progress);
    float flatten = smoothstep(0.35, 0.81, progress);
    float pinch = smoothstep(0.76, 0.98, progress);
    float extinction = 1.0 - smoothstep(0.87, 1.0, progress);

    vec2 aperture = (uv - 0.5) * vec2(2.0, -2.0);
    vec2 halfSize = mix(vec2(1.0), vec2(0.64, 0.72), intake);
    halfSize.y *= mix(1.0, 0.082, flatten);
    halfSize *= mix(vec2(1.0), vec2(0.069, 0.62), pinch);
    float bend = sin(aperture.x * 9.0 - progress * 16.0);
    aperture.y += bend * 0.085 * intake * (1.0 - flatten);
    vec2 folded = aperture / halfSize;
    float radius = length(folded);
    float antialias = clamp(fwidth(radius) * 0.7, 0.023, 0.16);
    float edgeWidth = mix(0.023, antialias, intake);
    float alpha = (1.0 - smoothstep(1.0 - edgeWidth, 1.0, radius)) * extinction;

#ifdef OIT_ALPHA_ONLY
    // Use the same moving aperture and visibility as the color pass.
    return vec4(0.0, 0.0, 0.0, alpha);
#else
    // Keep the original tunnel at closure onset. Its walls twist into the
    // inrush as the visible area contracts, then give way to the sealed seam.
    float tunnelWeight = 1.0 - smoothstep(0.10, 0.43, progress);
    vec3 tunnel = vec3(0.0);
    if (tunnelWeight > 0.0) {
        vec2 tunnelUv = vec2(0.5) + folded * vec2(0.5, -0.5);
        tunnel = renderWormhole(tunnelUv, viewPosition, time + intake * 6.0).rgb;
    }
    if (alpha <= 0.0) {
        discard;
    }

    float angle = atan(folded.y, folded.x + 0.00001);
    float ring = exp(-abs(radius - 0.88) * 27.0);
    float segments = 0.28 + 0.72 * smoothstep(-0.15, 0.86,
        cos(angle * 7.0 + radius * 8.0 - progress * 34.0));
    float inward = 0.5 + 0.5 * cos(radius * 27.0 + angle * 3.0 + progress * 42.0);
    float filaments = pow(inward, 11.0) * smoothstep(0.16, 0.52, radius);
    float pull = smoothstep(0.0, 0.19, progress) * (1.0 - flatten);
    vec3 current = vec3(0.11, 0.76, 1.0) * ring * segments;
    current += vec3(0.35, 0.10, 0.76) * filaments * segments * 0.62;

    float seam = exp(-abs(folded.y) * 7.5) * (1.0 - smoothstep(0.62, 1.0, abs(folded.x)));
    float knots = 0.65 + 0.35 * cos(folded.x * 18.0 + progress * 51.0);
    float spark = exp(-radius * 4.0) * pinch * 1.5;
    vec3 seamLight = vec3(0.09, 0.58, 0.92) * (seam * knots + ring * 0.48);
    seamLight += vec3(0.86, 0.97, 1.0) * (seam * seam * 0.76 + spark);

    vec3 color = mix(vec3(0.018, 0.012, 0.067), tunnel, tunnelWeight);
    color += current * pull + seamLight * flatten;
    return vec4(clamp(color, 0.0, 1.0), alpha);
#endif
}

#endif
