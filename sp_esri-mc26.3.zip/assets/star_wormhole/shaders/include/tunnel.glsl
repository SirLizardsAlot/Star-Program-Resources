#ifndef STAR_WORMHOLE_TUNNEL_GLSL
#define STAR_WORMHOLE_TUNNEL_GLSL

vec2 wormholeCenter(float z, float time) {
    float turn = time * 0.11;
    return 0.19 * vec2(sin(z * 0.39 + turn) - sin(turn),
                       cos(z * 0.31 - turn) - cos(turn)) * (1.0 - exp(-z));
}

float wormholeRadius(float z, float time) {
    return 1.07 + 0.07 * sin(z * 1.8 - time * 0.7)
                + 0.025 * sin(z * 4.7 + time * 0.35);
}

vec4 renderWormhole(vec2 uv, vec3 viewPosition, float time) {
    vec2 aperture = (uv - 0.5) * vec2(2.0, -2.0);
    float radius = length(aperture);
    float alpha = 1.0 - smoothstep(0.977, 1.0, radius);
#ifdef OIT_ALPHA_ONLY
    if (radius >= 1.0) {
        discard;
    }
    // OIT's depth/alpha pass needs the same silhouette, without shading walls.
    return vec4(0.0, 0.0, 0.0, alpha);
#else

    // Recover the actual transformed glyph plane from perspective-correct
    // varyings. The eye ray is expressed in that plane's own coordinate frame,
    // so turning the entity and walking around it both alter the tunnel view.
    vec3 dpdx = dFdx(viewPosition);
    vec3 dpdy = dFdy(viewPosition);
    vec2 duvdx = dFdx(uv);
    vec2 duvdy = dFdy(uv);
    float determinant = duvdx.x * duvdy.y - duvdx.y * duvdy.x;
    float safeDeterminant = abs(determinant) > 1e-12 ? determinant
        : (determinant < 0.0 ? -1e-12 : 1e-12);
    vec3 tangent = (dpdx * duvdy.y - dpdy * duvdx.y) / safeDeterminant;
    vec3 bitangent = (dpdy * duvdx.x - dpdx * duvdy.x) / safeDeterminant;
    float tangentLength = max(length(tangent), 1e-7);
    float bitangentLength = max(length(bitangent), 1e-7);
    tangent /= tangentLength;
    bitangent /= bitangentLength;
    vec3 normal = normalize(cross(tangent, bitangent));
    vec3 eyeRay = normalize(viewPosition);
    float axialScale = 0.5 * (tangentLength + bitangentLength);
    vec3 ray = normalize(vec3(dot(eyeRay, tangent) * axialScale / tangentLength,
                             -dot(eyeRay, bitangent) * axialScale / bitangentLength,
                             max(abs(dot(eyeRay, normal)), 0.025)));

    // Calculate screen derivatives before discarding the circular exterior.
    if (radius >= 1.0) {
        discard;
    }

    vec3 point = vec3(aperture, 0.015);
    float travel = 0.0;
    float wallDistance = 1.0;
    bool wallHit = false;
    // Fixed work bound and early exits keep the effect limited to its aperture.
    for (int stepIndex = 0; stepIndex < 64; ++stepIndex) {
        point = vec3(aperture, 0.015) + ray * travel;
        vec2 wallPoint = point.xy - wormholeCenter(point.z, time);
        wallDistance = wormholeRadius(point.z, time) - length(wallPoint);
        if (wallDistance < 0.006) {
            wallHit = true;
            break;
        }
        if (point.z > 36.0) {
            break;
        }
        travel += max(wallDistance * 0.62, 0.008);
    }

    vec3 color = vec3(0.002, 0.003, 0.012);
    if (wallHit) {
        vec2 wallPoint = point.xy - wormholeCenter(point.z, time);
        float angle = atan(wallPoint.y, wallPoint.x);
        float depth = point.z;
        float twist = angle * 7.0 + depth * 0.95 - time * 0.45;
        float ribs = pow(max(0.0, cos(twist + 0.5 * sin(depth * 1.2))), 12.0);
        float rings = pow(max(0.0, cos(depth * 5.0 - time * 1.35
            + 0.5 * sin(angle * 3.0 + depth * 0.4))), 20.0);
        float filaments = pow(max(0.0, cos(angle * 19.0 - depth * 2.1
            + time * 0.6)), 28.0);
        float cloud = 0.5 + 0.5 * sin(angle * 4.0 + sin(depth * 0.8 - time * 0.15));
        vec3 wallColor = mix(vec3(0.13, 0.025, 0.32), vec3(0.015, 0.29, 0.40), cloud);
        color = wallColor * (0.20 + 0.46 * ribs);
        color += vec3(0.075, 0.56, 0.70) * rings * (0.45 + 0.55 * ribs);
        color += vec3(0.36, 0.13, 0.63) * filaments * 0.45;
        color *= exp(-depth * 0.105);
        color += vec3(0.006, 0.009, 0.022) * (1.0 - exp(-depth * 0.09));
    } else {
        // The unresolved axis fades to a deep, distant throat rather than a cap.
        float throat = exp(-length(point.xy - wormholeCenter(point.z, time)) * 3.0);
        color += vec3(0.012, 0.018, 0.055) * throat;
    }

    float rim = exp(-pow((radius - 0.938) / 0.022, 2.0));
    float outerGlow = exp(-pow((radius - 0.945) / 0.065, 2.0));
    float angle = atan(aperture.y, aperture.x);
    float rimCurrent = 0.78 + 0.22 * sin(angle * 11.0 - time * 1.5);
    color += vec3(0.10, 0.72, 0.90) * rim * rimCurrent;
    color += vec3(0.10, 0.06, 0.30) * outerGlow;
    color = color / (vec3(1.0) + color * 0.35);
    return vec4(color, alpha);
#endif
}

#endif
