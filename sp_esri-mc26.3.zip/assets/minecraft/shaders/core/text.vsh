#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

uniform sampler2D Sampler0;
layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
layout(location = 4) flat out int wormholeMarker;
layout(location = 5) out vec2 wormholeUv;
layout(location = 6) out vec3 wormholeViewPosition;

// Bitmap glyphs are packed into a font atlas. A four-pixel signature at each
// corner identifies this particular glyph without using the requested font,
// text colour, atlas dimensions, or a fixed position in the atlas.
bool markerPixel(ivec2 p, ivec4 expected) {
    return all(equal(ivec4(round(texelFetch(Sampler0, p, 0) * 255.0)), expected));
}

void main() {
    vec4 viewPosition = ModelViewMat * vec4(Position, 1.0);
    gl_Position = ProjMat * viewPosition;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
    wormholeMarker = 0;
    wormholeUv = vec2(0.0);
    wormholeViewPosition = viewPosition.xyz;

#if !defined(IS_GUI) && !defined(IS_GRAYSCALE)
    ivec2 atlasSize = textureSize(Sampler0, 0);
    ivec2 corner = ivec2(floor(UV0 * vec2(atlasSize)));
    if (markerPixel(corner, ivec4(13, 47, 91, 255))) {
        for (int index = 0; index < 4; ++index) {
            ivec2 inward = ivec2((index & 1) == 0 ? 1 : -1,
                                (index & 2) == 0 ? 1 : -1);
            ivec2 inner = corner + inward;
            if (any(lessThan(inner, ivec2(0))) || any(greaterThanEqual(inner, atlasSize))) {
                continue;
            }
            if (markerPixel(corner + ivec2(inward.x, 0), ivec4(251, 17, 203, 255)) &&
                markerPixel(corner + ivec2(0, inward.y), ivec4(37, 229, 113, 255)) &&
                markerPixel(inner, ivec4(193, 73, 241, 255))) {
                ivec2 glyphOrigin = corner - ivec2(inward.x < 0 ? 63 : 0,
                                                  inward.y < 0 ? 63 : 0);
                // Vanilla's baked bitmap UVs have an inward .01 pixel inset.
                wormholeUv = (UV0 * vec2(atlasSize) - vec2(glyphOrigin) - 0.01) / 63.98;
                // ESRI sets this tint on both endpoints when the link starts to seal.
                // Read the unlit vertex color so the protocol survives lightmap changes.
                ivec3 tint = ivec3(round(Color.rgb * 255.0));
                wormholeMarker = all(equal(tint, ivec3(1, 255, 255))) ? 2 : 1;
                if (wormholeMarker == 2) {
                    vertexColor.a = Color.a;
                }
                break;
            }
        }
    }
#endif
}
